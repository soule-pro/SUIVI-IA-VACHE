# Tableau de bord IA – Application Android

Application Kotlin / Jetpack Compose qui reprend le classeur « Tableau de bord IA v3 » :
- lit l'export CSV KoboCollect (même lien et mêmes 11 colonnes que la requête Power Query),
- calcule le mois, le cumul de l'année, les taux de remontée, Par_province (47) et Par_commune (351),
- ouvre KoboCollect pour la saisie, garde les dernières données hors ligne, partage un résumé.

## Générer l'APK / le bundle
1. Installer Android Studio (Ladybug ou plus récent), puis `File > Open` et choisir ce dossier.
2. Laisser la synchronisation Gradle se terminer (connexion Internet requise la 1re fois).
3. Test : brancher un téléphone (mode développeur) et cliquer sur Run.
4. Publication : `Build > Generate Signed Bundle / APK`, créer un keystore (à conserver précieusement), choisir AAB (Play Store) ou APK.

## Configuration
Au 1er lancement : Réglages > nom d'utilisateur et mot de passe Kobo > Enregistrer.
Le lien d'export est pré-rempli avec celui du classeur.
Le référentiel (régions, provinces, communes) est dans `app/src/main/assets/referentiel.json`,
extrait de l'onglet Referentiel : les libellés doivent rester identiques à ceux du formulaire Kobo.

## Compiler sans Android Studio (GitHub)
1. Créer un compte gratuit sur github.com, puis un nouveau dépôt (New repository).
2. Cliquer « uploading an existing file » et déposer tout le contenu du dossier (y compris le dossier .github).
3. Onglet « Actions » > « Build APK » : attendre la coche verte (5 à 10 min).
4. Ouvrir l'exécution > section « Artifacts » > télécharger TableauBordIA-apk, dézipper, installer l'APK sur le téléphone.
