package bf.agriculture.tableaubordia

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

/** Lecteur minimal de fichiers .xlsx (premier onglet) : l'export Kobo est un classeur Excel. */
object XlsxReader {
    private fun parser(b: ByteArray): XmlPullParser = Xml.newPullParser().apply { setInput(ByteArrayInputStream(b), "UTF-8") }

    fun rows(bytes: ByteArray): List<List<String>> {
        val files = HashMap<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val n = e.name
                if (n == "xl/workbook.xml" || n == "xl/_rels/workbook.xml.rels" || n == "xl/sharedStrings.xml" || n.startsWith("xl/worksheets/")) files[n] = z.readBytes()
                e = z.nextEntry
            }
        }
        val shared = files["xl/sharedStrings.xml"]?.let { sharedStrings(it) } ?: emptyList()
        val sheet = firstSheetPath(files)?.let { files[it] }
            ?: files.filterKeys { it.startsWith("xl/worksheets/sheet") }.toSortedMap().values.firstOrNull()
            ?: return emptyList()
        return parseSheet(sheet, shared)
    }

    private fun firstSheetPath(files: Map<String, ByteArray>): String? {
        val wb = files["xl/workbook.xml"] ?: return null
        val rels = files["xl/_rels/workbook.xml.rels"] ?: return null
        var rid: String? = null
        val p = parser(wb)
        while (p.next() != XmlPullParser.END_DOCUMENT) {
            if (p.eventType == XmlPullParser.START_TAG && p.name == "sheet") {
                for (i in 0 until p.attributeCount) if (p.getAttributeName(i).endsWith(":id")) rid = p.getAttributeValue(i)
                break
            }
        }
        val id = rid ?: return null
        val q = parser(rels)
        var target: String? = null
        while (q.next() != XmlPullParser.END_DOCUMENT) {
            if (q.eventType == XmlPullParser.START_TAG && q.name == "Relationship" && q.getAttributeValue(null, "Id") == id) {
                target = q.getAttributeValue(null, "Target"); break
            }
        }
        val t = target ?: return null
        return if (t.startsWith("/")) t.removePrefix("/") else "xl/$t"
    }

    private fun sharedStrings(b: ByteArray): List<String> {
        val p = parser(b)
        val out = ArrayList<String>()
        var sb: StringBuilder? = null
        var inT = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) { "si" -> sb = StringBuilder(); "t" -> inT = true }
                XmlPullParser.TEXT -> if (inT) sb?.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "t" -> inT = false
                    "si" -> { out.add(sb?.toString() ?: ""); sb = null }
                }
            }
            ev = p.next()
        }
        return out
    }

    private fun colIndex(ref: String): Int {
        var n = 0
        for (ch in ref) { if (ch in 'A'..'Z') n = n * 26 + (ch - 'A' + 1) else break }
        return n - 1
    }

    private fun parseSheet(b: ByteArray, shared: List<String>): List<List<String>> {
        val p = parser(b)
        val rows = ArrayList<List<String>>()
        var cur: ArrayList<String>? = null
        var col = -1
        var type = ""
        var text = StringBuilder()
        var inV = false
        var inT = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "row" -> cur = ArrayList()
                    "c" -> {
                        type = p.getAttributeValue(null, "t") ?: ""
                        val ref = p.getAttributeValue(null, "r") ?: ""
                        col = if (ref.isEmpty()) -1 else colIndex(ref)
                        text = StringBuilder()
                    }
                    "v" -> inV = true
                    "t" -> inT = true
                }
                XmlPullParser.TEXT -> if (inV || inT) text.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "v" -> inV = false
                    "t" -> inT = false
                    "c" -> {
                        val value = if (type == "s") shared.getOrNull(text.toString().trim().toIntOrNull() ?: -1) ?: "" else text.toString()
                        val r = cur
                        if (r != null) {
                            val idx = if (col < 0) r.size else col
                            while (r.size < idx) r.add("")
                            if (r.size == idx) r.add(value) else r[idx] = value
                        }
                    }
                    "row" -> { cur?.let { rows.add(it) }; cur = null }
                }
            }
            ev = p.next()
        }
        return rows
    }
}
