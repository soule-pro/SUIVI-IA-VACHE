package bf.agriculture.tableaubordia

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Credentials
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

const val DEFAULT_URL = "https://kf.agriculture.bf/api/v2/assets/aApaMnJSXVMNhVTKG53Ldy/export-settings/esMd37sntCTLRZLfWLWNks7/data.xlsx"
const val KOBO_PACKAGE = "org.koboc.collect.android"

data class KoboSettings(val url: String, val user: String, val password: String) {
    val complete get() = url.isNotBlank() && user.isNotBlank() && password.isNotBlank()
}

class SettingsStore(ctx: Context) {
    private val prefs = try {
        val key = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(ctx, "secure_prefs", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    } catch (e: Exception) { ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE) }

    fun load() = KoboSettings((prefs.getString("url", DEFAULT_URL) ?: DEFAULT_URL).replace("/data.csv", "/data.xlsx"), prefs.getString("user", "") ?: "", prefs.getString("pwd", "") ?: "")
    fun save(s: KoboSettings) { prefs.edit().putString("url", s.url.trim()).putString("user", s.user.trim()).putString("pwd", s.password).apply() }
}

class Repository(ctx: Context) {
    private val client = OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(120, TimeUnit.SECONDS).build()
    private val cache = File(ctx.filesDir, "donnees.bin")

    val cacheTime: Long? get() = if (cache.exists()) cache.lastModified() else null
    fun readCache(): ByteArray? = if (cache.exists()) cache.readBytes() else null

    suspend fun download(s: KoboSettings): ByteArray = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(s.url)
            .header("Authorization", Credentials.basic(s.user, s.password, Charsets.UTF_8)).build()
        client.newCall(req).execute().use { r ->
            if (r.code == 401 || r.code == 403) error("Identifiants Kobo refusés (code ${r.code}).")
            if (!r.isSuccessful) error("Erreur du serveur Kobo (code ${r.code}).")
            val bytes = r.body?.bytes() ?: ByteArray(0)
            if (bytes.isEmpty()) error("L'export Kobo est vide.")
            if (bytes[0] == '<'.code.toByte()) error("Réponse inattendue du serveur (page web au lieu du fichier). Vérifiez le lien d'export.")
            cache.writeBytes(bytes)
            bytes
        }
    }
}
