package bf.agriculture.tableaubordia

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(
                primary = Color(0xFF2E7D32), onPrimary = Color.White,
                primaryContainer = Color(0xFFC8E6C9), onPrimaryContainer = Color(0xFF0B3D0F),
                secondary = Color(0xFF8D6E63), errorContainer = Color(0xFFFFDAD6)
            )) { App(vm) }
        }
    }
}
