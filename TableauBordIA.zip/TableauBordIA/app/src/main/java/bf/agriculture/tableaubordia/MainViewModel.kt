package bf.agriculture.tableaubordia

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.UnknownHostException
import java.util.Calendar

data class UiState(
    val year: Int, val month: Int, val years: List<Int>,
    val dashboard: Dashboard? = null,
    val loading: Boolean = false, val error: String? = null, val lastSync: Long? = null,
    val settings: KoboSettings,
    val diag: String = ""
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val store = SettingsStore(app)
    private val repo = Repository(app)
    private val ref = Referentiel.load(app)
    private var records: List<Record> = emptyList()

    private val _state = MutableStateFlow(
        Calendar.getInstance().let { UiState(it.get(Calendar.YEAR), it.get(Calendar.MONTH) + 1, listOf(it.get(Calendar.YEAR)), settings = store.load()) }
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            repo.readCache()?.let { txt ->
                records = withContext(Dispatchers.Default) { CsvParser.toRecords(txt) }
                _state.update { it.copy(lastSync = repo.cacheTime, diag = diagnose(txt)) }
                recompute(_state.value.year, _state.value.month)
            }
            if (store.load().complete) refresh()
        }
    }

    private fun diagnose(txt: String): String {
        val rows = CsvParser.rows(txt)
        val al = Aggregator.align(records, ref)
        val ok = al.count { it.region in ref.regions }
        val head = rows.firstOrNull()?.take(11)?.joinToString(" | ") ?: "(vide)"
        val sample = rows.getOrNull(1)?.take(11)?.joinToString(" | ") ?: "(aucune ligne)"
        return "DIAGNOSTIC – lignes lues : ${maxOf(0, rows.size - 1)} · fiches valides : ${records.size} · région reconnue : $ok\n" +
            "Années : ${records.groupingBy { it.year }.eachCount()}\nEn-têtes : $head\nExemple : $sample"
    }

    private fun recompute(y: Int, m: Int) {
        viewModelScope.launch {
            val d = withContext(Dispatchers.Default) { Aggregator.compute(records, ref, y, m) }
            val cy = Calendar.getInstance().get(Calendar.YEAR)
            val ys = (records.map { it.year } + cy + 2025).distinct().sorted()
            _state.update { it.copy(year = y, month = m, years = ys, dashboard = d) }
        }
    }

    fun setPeriod(y: Int, m: Int) = recompute(y, m)

    fun refresh() {
        val s = store.load()
        if (!s.complete) { _state.update { it.copy(error = "Renseignez vos identifiants Kobo dans Réglages.") }; return }
        if (_state.value.loading) return
        viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null) }
            try {
                val txt = repo.download(s)
                records = withContext(Dispatchers.Default) { CsvParser.toRecords(txt) }
                _state.update { it.copy(lastSync = System.currentTimeMillis(), diag = diagnose(txt)) }
                recompute(_state.value.year, _state.value.month)
            } catch (e: UnknownHostException) {
                _state.update { it.copy(error = "Pas de connexion. Affichage des dernières données enregistrées.") }
            } catch (e: Exception) {
                _state.update { it.copy(error = e.message ?: "Échec de l'actualisation.") }
            } finally {
                _state.update { it.copy(loading = false) }
            }
        }
    }

    fun saveSettings(s: KoboSettings) {
        store.save(s)
        _state.update { it.copy(settings = s) }
        refresh()
    }

    fun summary(): String {
        val st = _state.value; val d = st.dashboard ?: return "Aucune donnée."
        return buildString {
            appendLine("INSÉMINATION ARTIFICIELLE BOVINE – ${MOIS[st.month - 1]} ${st.year}")
            appendLine("Vaches inséminées : ${d.national.vaches}  (cumul ${st.year} : ${d.cumulVaches})")
            appendLine("Producteurs bénéficiaires : ${d.national.prod} (H ${d.national.ph} / F ${d.national.pf})")
            appendLine("Veaux nés : ${d.national.veaux}")
            appendLine("Provinces ayant transmis : ${d.provTransmises}/${d.provTotal}")
            appendLine(); appendLine("Par région :")
            d.regions.forEach { appendLine("- ${it.name} : ${it.s.vaches} vaches, ${it.provTransmises}/${it.provTotal} provinces") }
        }
    }
}
