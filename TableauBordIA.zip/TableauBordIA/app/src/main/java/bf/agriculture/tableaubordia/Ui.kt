package bf.agriculture.tableaubordia

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.text.format.DateFormat
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

private fun Int.fmt() = String.format(Locale.FRANCE, "%,d", this)
private fun Float.pct() = "${(this * 100).roundToInt()} %"

fun openKobo(ctx: Context) {
    val i = ctx.packageManager.getLaunchIntentForPackage(KOBO_PACKAGE)
        ?: Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$KOBO_PACKAGE"))
    try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$KOBO_PACKAGE")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

private fun share(ctx: Context, text: String) {
    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }, "Partager le résumé").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(vm: MainViewModel) {
    val st by vm.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    LaunchedEffect(st.settings.complete) { if (!st.settings.complete) tab = 3 }
    val tabs = listOf("Tableau de bord" to Icons.Default.Home, "Provinces" to Icons.Default.LocationOn, "Communes" to Icons.Default.Search, "Réglages" to Icons.Default.Settings)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Insémination artificielle", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primary, titleContentColor = Color.White, actionIconContentColor = Color.White),
                actions = {
                    if (st.loading) CircularProgressIndicator(Modifier.size(24.dp), color = Color.White, strokeWidth = 2.dp)
                    else IconButton({ vm.refresh() }) { Icon(Icons.Default.Refresh, "Actualiser") }
                    IconButton({ share(ctx, vm.summary()) }) { Icon(Icons.Default.Share, "Partager") }
                })
        },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(icon, label) }, label = { Text(label, fontSize = 10.sp, maxLines = 1) })
                }
            }
        },
        floatingActionButton = {
            if (tab != 3) ExtendedFloatingActionButton(onClick = { openKobo(ctx) }, icon = { Icon(Icons.Default.Edit, null) }, text = { Text("Saisir (Kobo)") })
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> DashboardScreen(st, vm)
                1 -> ProvincesScreen(st)
                2 -> CommunesScreen(st)
                else -> SettingsScreen(st, vm)
            }
        }
    }
}

@Composable
private fun Status(st: UiState) {
    val t = st.lastSync?.let { "Dernière mise à jour : " + DateFormat.format("dd/MM/yyyy HH:mm", Date(it)) } ?: "Jamais synchronisé"
    Column {
        Text(t, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        st.error?.let { Text(it, fontSize = 13.sp, color = MaterialTheme.colorScheme.error) }
    }
}

@Composable
private fun Picker(label: String, options: List<String>, selected: String, modifier: Modifier, onSelect: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton({ open = true }, Modifier.fillMaxWidth()) { Text("$label : $selected", maxLines = 1) }
        DropdownMenu(open, { open = false }) {
            options.forEachIndexed { i, o -> DropdownMenuItem(text = { Text(o) }, onClick = { open = false; onSelect(i) }) }
        }
    }
}

@Composable
private fun Kpi(title: String, value: String, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Column(Modifier.padding(12.dp)) {
            Text(title, fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
        }
    }
}

@Composable
private fun DashboardScreen(st: UiState, vm: MainViewModel) {
    val d = st.dashboard
    LazyColumn(contentPadding = PaddingValues(12.dp, 12.dp, 12.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Picker("Année", st.years.map { it.toString() }, st.year.toString(), Modifier.weight(1f)) { vm.setPeriod(st.years[it], st.month) }
                Picker("Mois", MOIS, MOIS[st.month - 1], Modifier.weight(1.4f)) { vm.setPeriod(st.year, it + 1) }
            }
        }
        item { Status(st) }
        if (d == null) {
            item { Text("Aucune donnée. Renseignez vos identifiants Kobo (Réglages) puis actualisez.", Modifier.padding(top = 24.dp)) }
        } else {
            val k = d.national
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Kpi("Vaches inséminées (mois)", k.vaches.fmt(), Modifier.weight(1f))
                        Kpi("Producteurs (H+F)", k.prod.fmt(), Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Kpi("Veaux nés (M+F)", k.veaux.fmt(), Modifier.weight(1f))
                        Kpi("Provinces ayant transmis", "${d.provTransmises}/${d.provTotal}", Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Kpi("Vaches inséminées (cumul ${st.year})", d.cumulVaches.fmt(), Modifier.weight(1f))
                        Kpi("Part des femmes", d.partFemmes.pct(), Modifier.weight(1f))
                    }
                }
            }
            if (d.unmatched > 0) item {
                Text("⚠ ${d.unmatched} fiche(s) du mois ont une province absente du référentiel (orthographe différente ?).", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
            }
            item { MonthlyChart(d.monthly, st.month, st.year) }
            item { Text("Détail par région", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
            items(d.regions) { RegionCard(it) }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
                    Column(Modifier.padding(12.dp).fillMaxWidth()) {
                        Text("TOTAL NATIONAL", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("${k.vaches.fmt()} vaches · ${k.prod.fmt()} producteurs (H ${k.ph} / F ${k.pf}) · ${k.veaux.fmt()} veaux (M ${k.vm} / F ${k.vf})", color = Color.White, fontSize = 13.sp)
                        Text("Taux de remontée : ${d.tauxNational.pct()} · Cumul : ${d.cumulVaches.fmt()}", color = Color.White, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun RegionCard(r: RegionRow) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(r.name, fontWeight = FontWeight.Bold)
                Text("${r.s.vaches.fmt()} vaches", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
            Text("Producteurs ${r.s.prod} (H ${r.s.ph} / F ${r.s.pf}) · Veaux ${r.s.veaux} (M ${r.s.vm} / F ${r.s.vf})", fontSize = 12.sp)
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(progress = { r.taux }, Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)))
            Text("Provinces ayant transmis : ${r.provTransmises}/${r.provTotal} (${r.taux.pct()}) · Cumul : ${r.cumulVaches.fmt()}", fontSize = 12.sp)
        }
    }
}

@Composable
private fun MonthlyChart(data: List<MonthPoint>, selected: Int, year: Int) {
    val max = (data.maxOfOrNull { it.vaches } ?: 0).coerceAtLeast(1)
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text("Évolution mensuelle $year – vaches inséminées", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().height(150.dp), verticalAlignment = Alignment.Bottom) {
                data.forEach { p ->
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                        if (p.vaches > 0) Text(p.vaches.toString(), fontSize = 8.sp, maxLines = 1)
                        Box(Modifier.width(14.dp).height((p.vaches.toFloat() / max * 100).dp.coerceAtLeast(2.dp))
                            .background(if (p.month == selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)))
                        Text(MOIS[p.month - 1].take(1), fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ProvincesScreen(st: UiState) {
    val d = st.dashboard
    var q by rememberSaveable { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(top = 12.dp), label = { Text("Rechercher une province / région") }, singleLine = true)
        if (d == null) { Text("Aucune donnée.", Modifier.padding(16.dp)); return }
        Text("${d.provTransmises}/${d.provTotal} provinces ont transmis en ${MOIS[st.month - 1]} ${st.year} (en rouge : rien transmis)", fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
        val list = d.provinces.filter { it.name.contains(q, true) || it.region.contains(q, true) || it.chefLieu.contains(q, true) }
        LazyColumn(contentPadding = PaddingValues(bottom = 96.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(list) { p ->
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = if (p.transmis) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.errorContainer)) {
                    Column(Modifier.padding(10.dp)) {
                        Text("${p.name} – ${p.region}", fontWeight = FontWeight.Bold)
                        Text("Chef-lieu : ${p.chefLieu}", fontSize = 12.sp)
                        Text("Mois : ${p.s.vaches} vaches · ${p.s.prod} producteurs (H ${p.s.ph}/F ${p.s.pf}) · ${p.s.veaux} veaux", fontSize = 12.sp)
                        Text("Cumul ${st.year} : ${p.cumulVaches.fmt()} vaches · ${p.cumulVeaux} veaux", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun CommunesScreen(st: UiState) {
    val d = st.dashboard
    var q by rememberSaveable { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(top = 12.dp), label = { Text("Rechercher une commune") }, singleLine = true)
        if (d == null) { Text("Aucune donnée.", Modifier.padding(16.dp)); return }
        val list = d.communes.filter { it.name.contains(q, true) || it.province.contains(q, true) || it.region.contains(q, true) }
        Text("${list.count { it.transmis }} commune(s) ayant transmis sur ${list.size}", fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
        LazyColumn(contentPadding = PaddingValues(bottom = 96.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(list) { c ->
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = if (c.transmis) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.errorContainer)) {
                    Row(Modifier.padding(10.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(c.name, fontWeight = FontWeight.Bold)
                            Text("${c.province} – ${c.region}", fontSize = 12.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("${c.s.vaches} vaches", fontSize = 13.sp)
                            Text("${c.s.prod} prod. · ${c.s.veaux} veaux", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(st: UiState, vm: MainViewModel) {
    var url by remember(st.settings.url) { mutableStateOf(st.settings.url) }
    var user by remember(st.settings.user) { mutableStateOf(st.settings.user) }
    var pwd by remember(st.settings.password) { mutableStateOf(st.settings.password) }
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Connexion à KoboToolbox", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text("L'application lit l'export CSV (en libellés) de votre formulaire, comme la requête Power Query du classeur Excel. Les identifiants sont stockés de façon chiffrée sur ce téléphone.", fontSize = 13.sp)
        OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth(), label = { Text("Lien d'export CSV Kobo") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
        OutlinedTextField(user, { user = it }, Modifier.fillMaxWidth(), label = { Text("Nom d'utilisateur Kobo") }, singleLine = true)
        OutlinedTextField(pwd, { pwd = it }, Modifier.fillMaxWidth(), label = { Text("Mot de passe Kobo") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
        Button({ vm.saveSettings(KoboSettings(url, user, pwd)) }, Modifier.fillMaxWidth(), enabled = KoboSettings(url, user, pwd).complete) { Text("Enregistrer et actualiser") }
        st.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        HorizontalDivider()
        Text("Saisie des données", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text("Les agents saisissent dans KoboCollect. Les données envoyées apparaissent ici après « Actualiser ».", fontSize = 13.sp)
        OutlinedButton({ openKobo(ctx) }, Modifier.fillMaxWidth()) { Text("Ouvrir KoboCollect") }
        Text("Version 1.0.0", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
