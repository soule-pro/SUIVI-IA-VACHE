package bf.agriculture.tableaubordia

import android.content.Context
import org.json.JSONObject

val MOIS = listOf("Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre")

/** Une ligne de l'export KoboCollect (colonnes A à K de la feuille Donnees). */
data class Record(
    val region: String, val province: String, val commune: String,
    val year: Int, val month: Int,
    val vaches: Int, val ph: Int, val pf: Int, val vm: Int, val vf: Int
)

data class Prov(val region: String, val name: String, val chefLieu: String, val code: String = "")
data class Com(val region: String, val province: String, val name: String, val code: String = "")

class Referentiel(val regions: List<String>, val regionCodes: Map<String, String>, val provinces: List<Prov>, val communes: List<Com>) {
    companion object {
        fun load(ctx: Context): Referentiel {
            val j = JSONObject(ctx.assets.open("referentiel.json").bufferedReader(Charsets.UTF_8).use { it.readText() })
            val r = j.getJSONArray("regions"); val p = j.getJSONArray("provinces"); val c = j.getJSONArray("communes")
            val rcj = j.optJSONObject("regionCodes")
            val rc = rcj?.keys()?.asSequence()?.associateWith { k -> rcj.getString(k) } ?: emptyMap()
            return Referentiel(
                (0 until r.length()).map { r.getString(it) }, rc,
                (0 until p.length()).map { p.getJSONObject(it).let { o -> Prov(o.getString("region"), o.getString("name"), o.optString("chefLieu"), o.optString("code")) } },
                (0 until c.length()).map { c.getJSONObject(it).let { o -> Com(o.optString("region"), o.getString("province"), o.getString("name"), o.optString("code")) } }
            )
        }
    }
}

data class Sums(val vaches: Int = 0, val ph: Int = 0, val pf: Int = 0, val vm: Int = 0, val vf: Int = 0) {
    val prod get() = ph + pf
    val veaux get() = vm + vf
    operator fun plus(o: Sums) = Sums(vaches + o.vaches, ph + o.ph, pf + o.pf, vm + o.vm, vf + o.vf)
}
fun List<Record>?.sums() = (this ?: emptyList()).fold(Sums()) { a, r -> a + Sums(r.vaches, r.ph, r.pf, r.vm, r.vf) }

data class RegionRow(val name: String, val s: Sums, val provTransmises: Int, val provTotal: Int, val cumulVaches: Int) {
    val taux get() = if (provTotal == 0) 0f else provTransmises.toFloat() / provTotal
}
data class ProvRow(val region: String, val name: String, val chefLieu: String, val s: Sums, val transmis: Boolean, val cumulVaches: Int, val cumulVeaux: Int)
data class ComRow(val region: String, val province: String, val name: String, val s: Sums, val transmis: Boolean)
data class MonthPoint(val month: Int, val vaches: Int, val prod: Int, val veaux: Int)

data class Dashboard(
    val regions: List<RegionRow>, val national: Sums,
    val provTransmises: Int, val provTotal: Int, val cumulVaches: Int, val cumulVeaux: Int,
    val monthly: List<MonthPoint>, val unmatched: Int,
    val provinces: List<ProvRow>, val communes: List<ComRow>
) {
    val partFemmes get() = if (national.prod == 0) 0f else national.pf.toFloat() / national.prod
    val tauxNational get() = if (provTotal == 0) 0f else provTransmises.toFloat() / provTotal
}

/** Reproduit les formules SUMIFS du classeur Excel. */
object Aggregator {
    fun norm(s: String): String =
        java.text.Normalizer.normalize(s.trim().lowercase(java.util.Locale.ROOT).replace('\u2019', '\'').replace(Regex("\\s+"), " "), java.text.Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")

    /** Rattache chaque fiche au référentiel : tolère accents, majuscules et codes Kobo. */
    fun align(raw: List<Record>, ref: Referentiel): List<Record> {
        val rn = HashMap<String, String>(); ref.regions.forEach { rn[norm(it)] = it }; ref.regionCodes.forEach { (c, l) -> rn[norm(c)] = l }
        val pn = HashMap<String, String>(); ref.provinces.forEach { pn[norm(it.name)] = it.name; if (it.code.isNotBlank()) pn[norm(it.code)] = it.name }
        val pReg = ref.provinces.associate { it.name to it.region }
        val cn = HashMap<Pair<String, String>, String>(); ref.communes.forEach { cn[norm(it.province) to norm(it.name)] = it.name }
        val cc = HashMap<String, Pair<String, String>>(); ref.communes.forEach { if (it.code.isNotBlank()) cc[norm(it.code)] = it.province to it.name }
        return raw.map { r ->
            val cm = cc[norm(r.commune)]
            val prov = pn[norm(r.province)] ?: cm?.first ?: r.province
            val reg = rn[norm(r.region)] ?: pReg[prov] ?: r.region
            val com = cm?.second ?: cn[norm(prov) to norm(r.commune)] ?: r.commune
            r.copy(region = reg, province = prov, commune = com)
        }
    }

    fun compute(allIn: List<Record>, ref: Referentiel, year: Int, month: Int): Dashboard {
        val all = align(allIn, ref)
        val yearRecs = all.filter { it.year == year }
        val monthRecs = yearRecs.filter { it.month == month }
        val cumulRecs = yearRecs.filter { it.month <= month }
        val mReg = monthRecs.groupBy { it.region }
        val cReg = cumulRecs.groupBy { it.region }
        val mProv = monthRecs.groupBy { it.province }
        val cProv = cumulRecs.groupBy { it.province }
        val mCom = monthRecs.groupBy { it.province to it.commune }

        val regions = ref.regions.map { reg ->
            val provs = ref.provinces.filter { it.region == reg }
            RegionRow(reg, mReg[reg].sums(), provs.count { !mProv[it.name].isNullOrEmpty() }, provs.size, cReg[reg].sums().vaches)
        }
        val provinces = ref.provinces.map {
            ProvRow(it.region, it.name, it.chefLieu, mProv[it.name].sums(), !mProv[it.name].isNullOrEmpty(),
                cProv[it.name].sums().vaches, cProv[it.name].sums().veaux)
        }
        val communes = ref.communes.map {
            val l = mCom[it.province to it.name]
            ComRow(it.region, it.province, it.name, l.sums(), !l.isNullOrEmpty())
        }
        val known = ref.provinces.map { it.name }.toSet()
        return Dashboard(
            regions = regions,
            national = regions.fold(Sums()) { a, r -> a + r.s },
            provTransmises = regions.sumOf { it.provTransmises },
            provTotal = ref.provinces.size,
            cumulVaches = regions.sumOf { it.cumulVaches },
            cumulVeaux = provinces.sumOf { it.cumulVeaux },
            monthly = (1..12).map { m -> yearRecs.filter { it.month == m }.sums().let { MonthPoint(m, it.vaches, it.prod, it.veaux) } },
            unmatched = monthRecs.count { it.province !in known },
            provinces = provinces, communes = communes
        )
    }
}

object CsvParser {
    fun rows(text: String): List<List<String>> {
        val t = text.removePrefix("\uFEFF")
        val first = t.lineSequence().firstOrNull() ?: ""
        val d = if (first.count { it == ';' } >= first.count { it == ',' }) ';' else ','
        val out = ArrayList<List<String>>(); var row = ArrayList<String>(); val sb = StringBuilder(); var q = false; var i = 0
        while (i < t.length) {
            val c = t[i]
            when {
                q && c == '"' && i + 1 < t.length && t[i + 1] == '"' -> { sb.append('"'); i++ }
                c == '"' -> q = !q
                !q && c == d -> { row.add(sb.toString()); sb.setLength(0) }
                !q && (c == '\n' || c == '\r') -> {
                    if (c == '\r' && i + 1 < t.length && t[i + 1] == '\n') i++
                    row.add(sb.toString()); sb.setLength(0)
                    if (row.any { it.isNotBlank() }) out.add(row); row = ArrayList()
                }
                else -> sb.append(c)
            }
            i++
        }
        if (sb.isNotEmpty() || row.isNotEmpty()) { row.add(sb.toString()); if (row.any { it.isNotBlank() }) out.add(row) }
        return out
    }

    fun int(s: String?) = s?.trim()?.replace(',', '.')?.toDoubleOrNull()?.toInt() ?: 0

    /** Mois de référence : "2026-10-01" ou "10/1/2026" (en-US, comme la requête Power Query). */
    fun ym(s: String): Pair<Int, Int> {
        val t = s.trim()
        Regex("^(\\d{5})(\\.\\d+)?$").find(t)?.let {
            val d = java.time.LocalDate.of(1899, 12, 30).plusDays(it.groupValues[1].toLong())
            return d.year to d.monthValue
        }
        Regex("^(\\d{4})-(\\d{1,2})-(\\d{1,2})").find(t)?.let { return it.groupValues[1].toInt() to it.groupValues[2].toInt() }
        Regex("^(\\d{4})/(\\d{1,2})/(\\d{1,2})").find(t)?.let { return it.groupValues[1].toInt() to it.groupValues[2].toInt() }
        Regex("^(\\d{1,2})/(\\d{1,2})/(\\d{4})").find(t)?.let { return it.groupValues[3].toInt() to it.groupValues[1].toInt() }
        return 0 to 0
    }

}

/** Lit un export Kobo (.xlsx comme dans Power Query, ou .csv) en repérant les colonnes par leur titre. */
object DataParser {
    fun rows(bytes: ByteArray): List<List<String>> =
        if (bytes.size > 4 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()) XlsxReader.rows(bytes)
        else CsvParser.rows(String(bytes, Charsets.UTF_8))

    fun toRecords(rows: List<List<String>>): List<Record> {
        if (rows.isEmpty()) return emptyList()
        val h = rows[0].map { Aggregator.norm(it.substringAfterLast('/')) }
        fun find(def: Int, pred: (String) -> Boolean) = h.indexOfFirst(pred).takeIf { it >= 0 } ?: def
        val iReg = find(0) { it == "region" }
        val iProv = find(1) { it == "province" }
        val iCom = find(2) { it == "commune" }
        val iMois = find(3) { it.startsWith("mois") }
        val iVac = find(4) { "vaches" in it }
        val iPh = find(5) { "producteurs" in it && "homme" in it }
        val iPf = find(6) { "producteurs" in it && "femme" in it }
        val iVf = find(8) { "veaux" in it && "femelle" in it }
        val iVm = find(7) { "veaux" in it && "femelle" !in it }
        fun List<String>.at(i: Int) = getOrNull(i) ?: ""
        return rows.drop(1).mapNotNull { r ->
            val (y, m) = CsvParser.ym(r.at(iMois))
            if (y == 0 || (r.at(iReg).isBlank() && r.at(iProv).isBlank())) null
            else Record(r.at(iReg).trim(), r.at(iProv).trim(), r.at(iCom).trim(), y, m,
                CsvParser.int(r.at(iVac)), CsvParser.int(r.at(iPh)), CsvParser.int(r.at(iPf)), CsvParser.int(r.at(iVm)), CsvParser.int(r.at(iVf)))
        }
    }
}
